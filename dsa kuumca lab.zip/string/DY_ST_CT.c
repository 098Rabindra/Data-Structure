/*concating two given strings dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i=0,j=0,k=0;
char *str1,*str2,*str3;
clrscr();
str1=(char *)malloc(sizeof(char));
str2=(char *)malloc(sizeof(char));
str3=(char *)malloc(sizeof(char));
puts("enter 1st strings:");
gets(str1);
puts("enter 2nd string:");
gets(str2);
while(str1[i]!='\0')
{
 str3[k]=str1[i];
 i++;k++;
 }
while(str2[j]!='\0')
{
 str3[k]=str2[j];
 k++;j++;
 }
 str3[k]='\0';
printf("the resultant string is:%s\n",str3);
getch();
}