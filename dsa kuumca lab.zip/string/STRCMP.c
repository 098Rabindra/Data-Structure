/*comparing two given strings*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
int n;
char str1[20],str2[20];
clrscr();
puts("enter 1st strings:");
gets(str1);
puts("enter 2nd string:");
gets(str2);
if(strcmp(str1,str2)==0)
printf("\n strings are equal");
else
printf("\n strings are not equal");
getch();
}