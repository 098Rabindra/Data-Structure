/*length of given string*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
int length;
char str[20];
clrscr();
puts("enter a string:");
gets(str);
length=strlen(str);
printf("length of string=%d",length);
getch();
}