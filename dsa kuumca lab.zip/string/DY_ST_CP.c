/*copy of contents of two given strings duynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i,j=0;
char *str1,*str2;
clrscr();
str1=(char *)malloc(sizeof(char));
str2=(char *)malloc(sizeof(char));
puts("enter 1st strings:");
gets(str1);
puts("enter 2nd string:");
gets(str2);
for(i=0;str1[i]!='\0';i++)
{
 str2[j]=str1[i];
 j++;
 }
 str2[j]='\0';
printf("the resultant string is:%s\n",str2);
getch();
}