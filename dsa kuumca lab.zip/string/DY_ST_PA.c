/*checking of string pallindrum dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i,j,p=0,flag;
char *str1;
clrscr();
str1=(char *)malloc(sizeof(char));
puts("enter 1st strings:");
gets(str1);
for(i=0;str1[i]!='\0';i++);
j=i-1;
while(p<=j)
{
 if(str1[p]==str1[j])
 flag=1;
 else
 {flag=0;break;}
 p++;j--;
 }
 if(flag==1)
 printf("\n string is pallindrum");
 else
  printf("\n string is not pallindrum");
getch();
}