/*concating two given strings*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
char str1[20],str2[20];
clrscr();
puts("enter 1st strings:");
gets(str1);
puts("enter 2nd string:");
gets(str2);
strcat(str1,str2);
printf("the resultant string is:%s\n",str1);
getch();
}