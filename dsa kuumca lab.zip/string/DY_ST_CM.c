/*comparing two given strings dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i,j,flag;
char *str1,*str2;
clrscr();
str1=(char *)malloc(sizeof(char));
str2=(char *)malloc(sizeof(char));
puts("enter 1st strings:");
gets(str1);
puts("enter 2nd string:");
gets(str2);
i=0;j=0;
while((str1[i]!='\0')||(str2[j]!='\0'))
{
if(str1[i]==str2[j])
flag=1;
else
flag=0;
i++; j++;
}
if(flag==1)
printf("\n strings are equal");
else
printf("\n strings are not equal");
getch();
}