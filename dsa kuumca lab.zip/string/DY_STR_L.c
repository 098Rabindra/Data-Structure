/*length of given string dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int length,i;
char *str;
clrscr();
str=(char *)malloc(sizeof(char));
puts("enter a string:");
gets(str);
for(i=0;str[i]!='\0';i++);
printf("length of string=%d",i);
getch();
}