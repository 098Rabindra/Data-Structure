#include<stdio.h>
#include<conio.h>
void main()
{
 int a[50],i,j,k,n,flag=0;
 clrscr();
 printf("\n\t\t DUPLICATE DELETION OF ARRAY");
 printf("\n\t\t----------------------------------");
 printf("\n enter the no. of elements u want to insert:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 for(i=0;i<n;i++)
  printf("%d  ",a[i]);
 for(i=0;i<n-1;i++)
 {
	for(j=i+1;j<n;j++)
	{
	 if(a[i]==a[j])
	 {
	  n--;
	  for(k=j;k<n;k++)
	   a[k]=a[k+1];
	  flag=1;j--;
	  }
	 }
   }
   if(flag==0)
   printf("\n array is with out duplicate");
   for(i=0;i<n;i++)
   printf("\n%d  ",a[i]);
  getch();
  }
