/*insert character in an array*/
#include<stdio.h>
#include<conio.h>
void main()
{
int i,n,temp,pos;char a[100],elem;
clrscr();
printf("enter the no. of elements in the array:");
scanf("%d",&n);fflush(stdin);
printf("\n Enter the elements\n");
for(i=0;i<n;i++)
{
 a[i]=getche();
 printf("\n a[%d]=%c\n",i,a[i]);
}
printf("\n enter the position of insertion:");
scanf("%d",&pos);fflush(stdin);
printf("\n enter the element,want to insert:");
elem=getche();
temp=n-1;
while(temp>=pos)
{
 a[temp+1]=a[temp];
 temp=temp-1;
 }
 a[pos]=elem;
 n++;
 for(i=0;i<n;i++)
 printf("\na[%d]=%c\n",i,a[i]);
 getch();
 }
