/*insert character in an array,dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i,n,temp,pos;char *a,elem;
clrscr();
printf("enter the no. of characters in the array:");
scanf("%d",&n);fflush(stdin);
a=(char *)malloc(n*sizeof(char));
printf("\n Enter the characters\n");
for(i=0;i<n;i++)
{
 a[i]=getche();
 printf("\n a[%d]=%c\n",i,a[i]);
}
printf("\n enter the position of insertion:");
scanf("%d",&pos);fflush(stdin);
printf("\n enter the character to be insert:");
elem=getche();
temp=n;
while(temp>=pos)
{
 a[temp+1]=a[temp];
 temp=temp-1;
 }
 a[pos+1]=elem;
 n++;
 for(i=0;i<n;i++)
 printf("\na[%d]=%c\n",i,a[i]);
 getch();
 }
