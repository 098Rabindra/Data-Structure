/*delet an element in an array*/
#include<stdio.h>
#include<conio.h>
void main()
{
int i,n,temp,pos,a[100];
clrscr();
printf("enter the no. of elements in the array:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
printf("a[%d]=%d\n",i,a[i]);
}
printf("\n enter the position of deletion:");
scanf("%d",&pos);
temp=pos;
while(temp<=n-1)
{
 a[temp]=a[temp+1];
 temp=temp+1;
 }
 n--;
 for(i=0;i<n;i++)
 printf("a[%d]=%d\n",i,a[i]);
 getch();
 }


