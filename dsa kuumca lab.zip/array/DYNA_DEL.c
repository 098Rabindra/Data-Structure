/*delet an element in an array dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
 int i,n,temp,pos,*a;
 clrscr();
 printf("enter the no. of elements in the array:\n");
 scanf("%d",&n);
 a=(int *)malloc(n*sizeof(int));
 for(i=0;i<n;i++)
 {
  printf("no.%d=",i+1);
  scanf("%d",(a+i));
 }
 printf("\n enter the position of deletion:");
 scanf("%d",&pos);
 temp=pos-1;
 while(temp<n)
 {
  a[temp]=a[temp+1];
  temp=temp+1;
  }
 n--;
 for(i=0;i<n;i++)
 printf("no.%d=%d\n",i+1,a[i]);
 getch();
}


