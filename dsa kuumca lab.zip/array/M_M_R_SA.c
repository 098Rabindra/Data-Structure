/*enter n no.s & find their sum,avg,max,min,range*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
 int n,i,*a,max,min,range,sum;
 float avg;
 clrscr();
 printf("enter the value of n:");
 scanf("%d",&n);
 a=(int *)malloc(n*sizeof(int));
 printf("\n enter the element of array\n");
 for(i=0;i<n;i++)
 {
  printf("no.%d=",i+1);
  scanf("%d",(a+i));
 }
 max=min=a[1];
 for(i=2;i<n;i++)
 {
  if(a[i]>=max)
    max=a[i];
  else
  {
   if(a[i]<=min)
     min=a[i];
   }
  }
  printf("max=%d,min=%d",max,min);
  range=max-min;
  printf("\n range of given data is:%d",range);
  sum=0;
  for(i=0;i<n;i++)
  sum+=a[i];
  avg=(float)sum/n;
  printf("\n sum=%d,\t avg=%f",sum,avg);
 getch();
}
