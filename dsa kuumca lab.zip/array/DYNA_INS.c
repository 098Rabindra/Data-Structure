/*insert an element in an array dynamically*/
#include<stdio.h>
#include<malloc.h>
#include<conio.h>
void main()
{
int i,n,temp,pos,*a,elem;
clrscr();
printf("enter the no. of elements in the array:\n");
scanf("%d",&n);
a=(int *)malloc(n*sizeof(int));
for(i=0;i<n;i++)
{
 printf("no.%d=",i+1);
 scanf("%d",(a+i));
}
printf("\n enter the position of insertion:");
scanf("%d",&pos);
printf("\n enter the element,want to insert:");
scanf("%d",&elem);
temp=n;
while(temp>=pos)
{
 a[temp+1]=a[temp];
 temp=temp-1;
 }
 a[pos]=elem;
 n++;
 for(i=0;i<n;i++)
 printf("a[%d]=%d\n",i+1,a[i]);
 getch();
 }
