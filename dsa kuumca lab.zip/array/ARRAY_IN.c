/*insert an element in an array*/
#include<stdio.h>
#include<conio.h>
void main()
{
int i,n,temp,pos,a[100],elem;
clrscr();
printf("enter the no. of elements,want to insert:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
 scanf("%d",&a[i]);
 printf("a[%d]=%d\n",i,a[i]);
}
printf("enter the position of insertion:");
scanf("%d",&pos);
printf("enter the element,want to insert:");
scanf("%d",&elem);
temp=n;
while(temp>=pos)
{
 a[temp+1]=a[temp];
 temp=temp-1;
 }
 a[pos]=elem;
 n++;
 for(i=0;i<n;i++)
 printf("a[%d]=%d\n",i,a[i]);
 getch();
 }
