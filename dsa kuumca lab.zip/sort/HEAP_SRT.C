/*heap sort*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,n,l[50],temp,j,k;
 clrscr();
 printf("\n\t\tHEAP SORT");
 printf("\n\t=====================");
 printf("\n the no. of elements in array is:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 scanf("%d",&l[i]);
 printf("\n entered list is:");
 display(l,n);
 creat_heap(l,n);
 printf("\nheap\n");
 display(l,n);
 printf("\n\n");
 heap_sort(l,n);
 printf("\nafter sorting list is:");
 display(l,n);
 getch();
 }
 /*--------------------*/
 display(int l[],int n)
 {
  int i;
  for(i=1;i<=n;i++)
  printf("%d|",l[i]);
  return;
  }
  /*------------------------*/
 creat_heap(int l[],int n)
 {
  int k,i,temp,j;
  for(k=2;k<=n;k++)
  {
   i=k;temp=l[k];
   j=i/2;
   while((i>1)&&(temp>l[j]))
   {
    l[i]=l[j];
    i=j;
    j=i/2;
    if(j<1)
    j=1;
    }
   l[i]=temp;
   }
   return;
   }
   /*----------------------*/
heap_sort(int l[],int n)
{
 int k,temp,i,j,p,value;
 for(k=n;k>=2;--k)
 {
  temp=l[1];l[1]=l[k];l[k]=temp;
  i=1;value=l[1];j=2;
  if((j+1)<k)
  {
   if(l[j+1]>l[j])
   j++;
   }
  while((j<=(k-1)) && (l[j]>value))
  {
   l[i]=l[j];
   i=j;j=2*i;
   if((j+1)<k)
    if(l[j+1]>l[j])
    j++;
    else if(j>n) j=n;
   l[i]=value;
   }
   for(p=1;p<=n;p++)
   printf("%d|",l[p]);
  }
   return;
   }
