   /*quick sort*/
#include<stdio.h>
#include<conio.h>
int i,a[30],n,temp;
void main()
{
 clrscr();
 printf("\t\t Quick Sort\n");
 printf("\n\t======================\n");

 printf("\n enter the no. of elements in the array:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);

 printf("\n entered unsorted list is as follows:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 printf("\n\n");
 quick_sort(a,0,n-1);

 printf("\n sorted list is:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 getch();
}
 /*____________________________*/
 quick_sort(int a[],int first,int last)
 {
  int low,high,pivot,temp;
  low=first;
  high=last;
  pivot=a[(first+last)/2];
  while(low<=high)
  {
   while(a[low]<pivot)
	 low++;
   while(a[high]>pivot)
	 high--;
   if(low<=high)
   {
    temp=a[low];
    a[low]=a[high];
    a[high]=temp;
    low++;high--;
    }
   }
   if(first<high)
   quick_sort(a,first,high);
   if(low<last)
   quick_sort(a,low,last);
   return;
  }
