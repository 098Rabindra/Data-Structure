/*selection sort*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,j,n,a[30],temp;
 clrscr();
 printf("\t Selection Sort\n");
 printf("\t__________________\n");
 printf("\n no. of elements in the array is:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 printf("\n unsorted list is:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 for(i=0;i<n;i++)
 {
  for(j=i+1;j<n;j++)
  {
   if(a[i]>a[j])
   {
     temp=a[i];
     a[i]=a[j];
     a[j]=temp;
    }
   }
 }
  printf("\n\n");
  printf("\n sortd list is:");
  for(i=0;i<n;i++)
  printf("%d\t",a[i]);
  getch();
 }
