/*selection sort*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,j,n,a[30],temp,min;
 clrscr();
 printf("\t Selection Sort\n");
 printf("\t__________________\n");
 printf("\n no. of elements in the array is:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 printf("\n unsorted list is:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 for(i=0;i<n-1;i++)
 {
  min=i;
  for(j=i+1;j<n;j++)
  {
   if(a[min]>a[j])
       min=j;
   }
  if(min!=i)
  {
    temp=a[i];
    a[i]=a[min];
    a[min]=temp;
  }
 }
  printf("\n\n");
  printf("\n sortd list is:");
  for(i=0;i<n;i++)
  printf("%d\t",a[i]);
  getch();
 }
