/*meage sort*/
#include<stdio.h>
#include<conio.h>
void merge_sort(int *,int,int);
void merge_pass(int *,int,int,int);
void main()
{
 int l[50],i,n;
 clrscr();
 printf("\n\t\tMERGE SORT");
 printf("\n\t\t===============");
 printf("\n no. of elements in array:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&l[i]);
 printf("\n the unsorted list is:");
 for(i=0;i<n;i++)
 printf("%d|",l[i]);
 i=0;
 merge_sort(l,i,n-1);
 printf("\n after merge sort,sorted list is:\n");
 for(i=0;i<n;i++)
 printf("%d|",l[i]);
 getch();
 }
 /*-------------------------------*/
 void merge_sort(int l[],int m,int n)
 {
  int mid;
  if(m!=n)
  {
   mid=(m+n)/2;
   merge_sort(l,m,mid);
   merge_sort(l,mid+1,n);
   merge_pass(l,m,mid,n);
   }
  }
  /*---------------------------*/
 void merge_pass(int l[],int top,int size,int bottom)
  {
   int upper;
   int t[50],f=top,s=size+1,h=top,lo=bottom,up=upper;
   while((f<=size) && (s<=lo))
   {
    if(l[f]<=l[s])
       {t[h]=l[f];f++;}
    else
       {t[h]=l[s];s++;}
     h++;
   }
     if(f<=size)
     {
      for(f=f;f<=size;f++)
      {t[h]=l[f];h++;}
     }
     else
     {
      for(s=s;s<=lo;s++)
      {t[h]=l[s];h++;}
     }
      for(up=top;up<=lo;up++)
      {l[up]=t[up];}
  }
