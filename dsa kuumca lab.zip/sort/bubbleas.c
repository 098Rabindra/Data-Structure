/*bubble sort*/
#include<stdio.h>
//#include<conio.h>
int main()
{
 int i,j,n,a[30],temp;
 //clrscr();
 printf("\t Buble Sort\n");
 printf("\t__________________\n");
 printf("\n enter the no. of elements in the array:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 
 printf("\n entered unsorted list is as follows:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 
	for(i=0;i<n-1;i++)
	{
	 for(j=0;j<n-1;j++)
	 {
	  if(a[j]>a[j+1])
	  {
	   temp=a[j];
	   a[j]=a[j+1];
	   a[j+1]=temp;
	  }
	 }
	}
	 printf("\n\n");
	 printf("\n sorted list is:\n");
	 for(j=0;j<n;j++)
	 printf("%d\t",a[j]);
//  getch();
return 0;
 }
