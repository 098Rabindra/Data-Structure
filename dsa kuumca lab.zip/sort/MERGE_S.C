/*MERGE SORT*/
#include<stdio.h>
#include<conio.h>
int i,j,k,n,m,p,l,a[100],b[100],c[200],temp;

bubble_sort(int n,int p[])  /*bubble sort*/
{
 int i,j,temp;
 for(i=0;i<n;i++)
 {
  for(j=0;j<n-1;j++)
  {
   if(p[j]>p[j+1])
   {
     temp=p[j];
     p[j]=p[j+1];
     p[j+1]=temp;
    }
   }
 }
  printf("\n\n");
  printf("\n sorted list is:\n");
  for(i=0;i<n;i++)
  printf("%d\t",p[i]);
  return;
}
void main()
{
  clrscr();
  printf("\t\t\t MERGE SORT");
  printf("\n\t\t===================");
  printf("\n No. of elements in the 1st array is:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  scanf("%d",&a[i]);
  bubble_sort(n,a);  /*sort elements of list_a*/

  printf("\n no. of elements in the 2nd array is:");
  scanf("%d",&m);
  for(j=0;j<m;j++)
  scanf("%d",&b[j]);

  bubble_sort(m,b); /*sort elements of list_b*/

  k=merge_sort(n,a,m,b,c);
  printf("\n sorted list is:\n"); /*after merge the sorted list_c*/
  for(i=0;i<k;i++)
  printf("%d\t",c[i]);
  getch();
 }
 /*---------------------------------*/
 merge_sort(int n,int a[],int m,int b[],int c[])
 {
   int i=j=k=0;
   while((i<n) && (j<m))
  {
   if(a[i]<b[j])
   {
    c[k]=a[i];
    i++;  k++;
   }
   else if(a[i]>b[j])
   {
    c[k]=b[j];
    j++; k++;
   }
   else
   {
    c[k]=a[i];
    i++; j++;  k++;
    }
    printf("\n");
  }
  if(i<n)    /*size of list_a is larger then the list_b*/
  {
   for(p=i;p<n;p++)
   {
    c[k]=a[p];
     i++; k++;
    }
   }
   else if(j<m)      /*size of list_b is larger then the list_a*/
   {
     for(p=j;p<m;p++)
     {
       c[k]=b[p];
       j++; k++;
      }
    }
  printf("\n\n");
  return(k);
}
