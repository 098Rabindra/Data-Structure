/*selection sort*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,j,n,a[30],temp,max;
 clrscr();
 printf("\t Selection Sort\n");
 printf("\t__________________\n");
 printf("\n no. of elements in the array is:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 printf("\n unsorted list is:\n");
 for(i=0;i<n;i++)
 printf("%d\t",a[i]);
 for(i=0;i<n-1;i++)
 {
  max=i;
  for(j=i+1;j<n;j++)
  {
   if(a[max]<a[j])
       max=j;
   }
  if(max!=i)
  {
    temp=a[i];
    a[i]=a[max];
    a[max]=temp;
  }
 }
  printf("\n\n");
  printf("\n sortd list is:");
  for(i=0;i<n;i++)
  printf("%d\t",a[i]);
  getch();
 }
