/*insertion sort*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,j,n,p,a[30],temp;
 clrscr();
 printf("\t Insertion Sort\n");
 printf("\t__________________\n");
 printf("\n no. of elements in the array is:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 scanf("%d",&a[i]);
 printf("\n unsorted list is:\n");
 for(i=1;i<=n;i++)
 printf("%d\t",a[i]);
 a[0]=100;
 for(i=1;i<=n;i++)
 {
  p=i-1;
  temp=a[i];
  while(temp>a[p])
  {
   a[p+1]=a[p];
   p--;
   }
  a[p+1]=temp;
  }
  printf("\n\n");
  printf("\n sorted list is:\n");
  for(i=1;i<=n;i++)
  printf("%d\t",a[i]);
  getch();
 }
