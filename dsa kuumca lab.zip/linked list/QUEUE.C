/*implementation of queue using linked list*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	 int info;
	 struct list *next;
	 };
typedef struct list qlist;
void main()
{
 qlist *first=NULL,*last=NULL;
  void insert();
 void delet();
 void display();

 int x,new_element;
 clrscr();
 printf("\n\tIMPLEMENTATION OF QUEUE USING LINKED LIST");
 printf("\n\t=======================================================");
 do
 {
  printf("\n1.insert\n2.delet\n3.exit");
  printf("\n enter ur choice:");
  scanf("%d",&x);
  switch(x)
  {
   case 1:
	  printf("\n enter an element to be inserted:");
	  scanf("%d",&new_element);
	  insert(&first,&last,new_element);
	  printf("\n\t****Queue*****\n");
	  display(first);
	  break;
   case 2:
	  delet(&first);
	  printf("\n*****Queue****\n");
	  display(first);
	  break;
   case 3:exit(0);
   }
   }while(x!=3);
  getch();
 }
 /*----------------------*/
 void display(qlist *node)
 {
  printf("\nstart");
  while(node!=NULL)
  {
   printf("->%d",node->info);
   node=node->next;
   }
   printf("->NULL\n");
   return;
  }
  /*----------------------*/
 void insert(qlist **first,qlist **last,int i)
 {
     qlist *new;
     new=(qlist *)malloc(sizeof(qlist));
     new->info=i;
     new->next=NULL;
    if((*first)==NULL)
     {
      (*first)=new;
      (*last)=new;
      }
      else
     {
       (*last)->next=new;
       (*last)=new;
      }
   return;
   }
  /*---------------------*/
 void delet(qlist **first)
 {
  qlist *temp;
    if((*first)!=NULL)
    {
     temp=*first;
     (*first)=(*first)->next;
     free(temp);
    }
   return;
   }
  /*--------------------*/
