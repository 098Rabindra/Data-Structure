/*multiplication of two polynomial lists*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	 int coeff,expo;
	 struct list *next;
	 };
typedef struct list polylist;
polylist *start,*node,*node1,*node2,*node3,*start1,*start2,*start3,*node4,*start4;
void main()
{
 node1=node2=node3=NULL;
 clrscr();
 printf("\t\t\tPOLYNOMIAL MULTIPLICATION");
 printf("\n\t\t========================================");
 printf("\n the first list is:\n");
 printf("---------------------------");
 creat(&node1);
 printf("\n after creating list1 is:\n");
 display(node1);
 clrscr();
 printf("\n the second list is:\n");
 printf("-------------------------------");
 creat(&node2);
 printf("\n after creating list2 is:\n");
 display(node2);
 clrscr();
 poly_mul(node1,node2,&node3);
 clrscr();
 printf("\n after multiplication of two polynomial lists,result list is:");
 display(node3);
 getch();
 delpoly(&node1);
 delpoly(&node2);
 delpoly(&node3);
 }
 /*----------------------*/
 creat(polylist **node)
 {
   int expo,coeff,a;
   printf("\n enter the terms:");
  while(a!=0)
  {
   printf("\nthe coefficient is:");
   scanf("%d",&coeff);
   printf("\nthe exponent is:");
   scanf("%d",&expo);
   addnode(node,coeff,expo);
   printf("do u want more(exit=0):");
   scanf("%d",&a);
   }
  return;
 }
 /*-------------------------*/
 display(polylist *node)
 {
  if(node!=NULL)
   printf("%dx^%d",node->coeff,node->expo);
  for(node=node->next;node!=NULL;node=node->next)
  {
   if(node->coeff>0)
     printf("+");
   if(node->expo==0)
    printf("%d",node->coeff);
   else
    if(node->expo==1)
     printf("%dx",node->coeff);
   else
     printf("%dx^%d",node->coeff,node->expo);
   }
  return;
  }
  /*-----------------------------*/
  delpoly(polylist **node)
  {
   polylist *temp;
   while(*node!=NULL)
   {
    temp=*node;
    *node=(*node)->next;
    free(temp);
    }
    return;
    }
   /*---------------------------------*/
  addnode(polylist **node,int coeff,int expo)
  {
    polylist *new;
    static polylist *last;
    new=(polylist *)malloc(sizeof(polylist));
    new->coeff=coeff;
    new->expo=expo;
    new->next=NULL;
    if(*node==NULL)
    {
     *node=last=new;
     }
    else
     {
      last->next=new;
      last=new;
      }
    return;
  }
  /*-----------------------*/
  poly_mul(polylist *node1,polylist *node2,polylist **node3)
  {
   int coeff,expo;
   polylist *temp,*loc,*tt;
   while(node1!=NULL)
   {
    temp=node2;
    while(temp!=NULL)
    {
     expo=node1->expo+temp->expo;
     coeff=node1->coeff*temp->coeff;
     tt=*node3;
     loc=search(tt,expo);
     if(loc==NULL)
      ins_node(&node3,coeff,expo);
     else
      loc->coeff+=coeff;
     temp=temp->next;
    }
   node1=node1->next;
   }
  return;
  }
  /*-----------------------*/
  search(polylist *node,int degree)
  {
   while(node!=NULL)
   {
    if(node->expo==degree)
       break;
    node=node->next;
    }
    return;
   }
   /*-------------------------*/
  ins_node
