/*spliting of a linked list*/
#include<stdio.h>
#include<conio.h>
struct list
   {
    int info;
    struct list *next;
    };
typedef struct list splist;
splist *start,*node,*prev;
int n,k;
void main()
{
 clrscr();
 printf("\n\t\t SPLITING OF LINKED LIST");
 printf("\n\t\t---------------------------");
 creat(node);
 display(node);
 split(n,node);
 getch();
}
/*-------------------------------*/
creat(splist *node)
{
 int i;
 printf("\n no. of elements u want to be insert:");
 scanf("%d",&n);
 node=start;
 for(i=0;i<n;i++)
 {
  node->next=(splist *)malloc(sizeof(splist));
  node=node->next;
  printf("\n value of node:");
  scanf("%d",&node->info);
  node->next=NULL;
  }return;
 }
 /*-------------------------*/
 display(splist *node)
 {
  node=start->next;
  while(node!=NULL)
  {
   printf("%d->",node->info);
   node=node->next;
   }return;
  }
 /*-------------------------*/
 split(int n,splist *node)
 {
  int c=0;
  splist *start1,*prev;
  node=start->next;prev=start;
  if(node==NULL)
  {printf("\n list is empty");return;}
  else
  {
   printf("\n enter the location of split:");
   scanf("%d",&k);
   if(k>(n-1))
   {printf("\n the position of spliting is absent in list");return;}
   else
    while((c++)!=k)
    {
     node=node->next;  prev=prev->next;
    }
   start1=node;
    prev->next=NULL;
   printf("\n after spliting first list is:");
   display(start1);
   printf("\n after spliting second list is:");
   while(node!=NULL)
   {
    printf("%d->",node->info);
    node=node->next;
   }
 }
   return;
  }