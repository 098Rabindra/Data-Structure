/*reverse a linked list*/
#include<stdio.h>
#include<conio.h>
struct list
       {
	int info;
	struct list *next;
	};
typedef struct list llist;
llist *start,*temp,*node,*ptr;
int i,n;
void main()
{
 clrscr();
 creat(node);
 printf("\n the original list is:");
 display(node);
 reverse(node);
 printf("\n after reversing list is:");
 display(node);
 getch();
 }
 /*--------------------------------*/
 creat(llist *node)
 {
  int n,i;
  printf("enter the no. of nodes to be creat:");
  scanf("%d",&n);
  node=start;
  for(i=0;i<n;i++)
  {
   node->next=(llist *)malloc(sizeof(llist));
   node=node->next;
   printf("\n the value of node:");
   scanf("%d",&node->info);
   if(i==(n-1))
   node->next=NULL;
    }
   return;
  }
 /*--------------------------------*/
 display(llist *node)
 {
  node=start->next;
  while(node!=NULL)
  {
   printf("%d->",node->info);
   node=node->next;
   }
   return;
  }
 /*-------------------------------*/
 reverse(llist *node)
{
  int s[30],i,top=0;
  node=start->next;
  while(node!=NULL)
  {
   top++;
   s[top]=node->info;
   node=node->next;
   }
   node=start->next;
  while(top>0)
  {
   node->info=s[top];
   top--;
   node=node->next;
   }
  return;
 }
  /*--------------------------------*/