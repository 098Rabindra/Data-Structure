 /*double linked list*/
 #include<stdio.h>
 #include<conio.h>
 struct list
	{
	 int info;
	 struct list *next;
	 struct list *prev;
	 };
typedef struct list dlist;
dlist *node,*start,*value,*new1,*temp;
void main()
{
 int x;
 dlist *node;
 clrscr();
 node=(dlist *)malloc(sizeof(dlist));
 do
 {
  printf("\n DOUBLE LINKED LIST");
  printf("\n ------------------------");
  printf("\n1.creat\n2.display\n3.ins_beg\n4.ins_end\n5.ins_loc\n6.del_beg\n7.del_end\n8.del_loc\n9.swap_a2\n10.clrscr\n11.exit");
  printf("\n enter ur choice:");
  scanf("%d",&x);
  switch(x)
  {
   case 1:creat(node);break;
   case 2:display(node);break;
   case 3:ins_beg(node);break;
   case 4:ins_end(node);break;
   case 5:ins_loc(node);break;
   case 6:del_beg(node);break;
   case 7:del_end(node);break;
   case 8:del_loc(node);break;
   case 9:swap_a2(node);break;
   case 10:clrscr();break;
   case 11:exit(0);
   }
  }while(x!=11);
  getch();
 }
 /*--------------------------------*/
 creat(dlist *node)
 {
  int i,n;
  start->next=NULL;
  start->prev=NULL;
  node=start;
  printf("\n no. of nodes u want to be creat:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
   node->next=(dlist *)malloc(sizeof(dlist));
   (node->next)->prev=node;
   node=node->next;
   printf("value:");
   scanf("%d",&node->info);
   node->next=NULL;
   }
  return;
 }
 /*---------------------------------*/
 display(dlist *node)
 {
  node=start;
  while(node->next!=NULL)
  {
   node=node->next;
   printf("%d->",node->info);
   }
  while(node->prev!=NULL)
  {
   node=node->prev;
   printf("%d->",node->info);
   }
  return;
 }
 /*--------------------------------*/
 ins_beg(dlist *node)
 {
  node=start->next;
  if(node==NULL)
  printf("\n list is empty & insert as a first node");
  else
  {
   new1=(dlist *)malloc(sizeof(dlist));
   printf("value of new1=");
   scanf("%d",&new1->info);
   new1->next=node;
   new1->prev=start;
   start->next=new1;
   node->prev=new1;
  }
  display(node);
 return;
}
/*--------------------------------*/
ins_end(dlist *node)
{
 node=start->next;
 new1=(dlist *)malloc(sizeof(dlist));
 printf("value of new1=");
 scanf("%d",&new1->info);
 if(node==NULL)
 printf("\n list is empty & insert as last node");
 else
 while(node->next!=NULL)
   node=node->next;
 new1->next=NULL;
 new1->prev=node;
 node->next=new1;
 printf("\n after insertion at the end of list is:");
  display(node);
 return;
 }
 /*-------------------------*/
 ins_loc(dlist *node)
 {
  int c=1,loc;
  node=start->next;temp=start;
  new1=(dlist *)malloc(sizeof(dlist));
  printf("value of new1=");
  scanf("%d",&new1->info);
  printf("\n insert location of insertion:");
  scanf("%d",&loc);
  if(node==NULL)
    printf("\n list is empty & insert as last node");
  else
   while(c!=loc)
    {node=node->next;temp=temp->next;c++;}
    new1->next=node;
    new1->prev=temp;
    node->prev=new1;
    temp->next=new1;
   display(node);
   return;
 }
/*-----------------------*/
 del_beg(dlist *node)
 {
  node=start->next;
  if(node==NULL)
  {printf("\n underflow");return;}
  else
  {
   start->next=node->next;
   (node->next)->prev=node->prev;
   free(node);
   }
  printf("\n after deletion list is:");
  display(node);
  return;
 }
 /*---------------------------*/
 del_end(dlist *node)
 {
  node=start->next;
  if(node==NULL)
  {printf("\n underflow");return;}
  else
  {
    while(node->next!=NULL)
     node=node->next;
   (node->prev)->next=NULL;
   free(node);
   printf("\n after deletion list is:");
   display(node);
   }
 return;
 }
 /*--------------------------*/
 del_loc(dlist *node)
 {
  int c=1,loc;
  node=start->next;
  printf("\n enter the location of deletion:");
  scanf("%d",&loc);
  if(node==NULL)
  {printf("\n underflow");return;}
  else
  {
    while(c!=loc)
     {node=node->next;c++;}
   (node->prev)->next=node->next;
   (node->next)->prev=node->prev;
   free(node);
   printf("\n after deletion list is:");
   display(node);
   }
 return;
 }
 /*------------------------------*/
 swap_a2(dlist *node)
 {
  int x;
  dlist *prev;
  prev=start->next;
  if(prev->info==NULL)
   printf("\n list is empty");
  else
    node=prev->next;
  x=node->info;
  node->info=prev->info;
  prev->info=x;
  display(node);
  return;
  }