/*sorting a linked list & search an element in a sorted linked list*/
#include<stdio.h>
#include<conio.h>
struct list
       {
	int info;
	struct list *next;
	};
typedef struct list llist;
llist *start=NULL,*temp,*prev,*loc,*node;int i,n;
void main()
{
 int x;
 clrscr();
do
{
 printf("\n1.creat\n2.display\n3.sorting\n4.ins_sort\n5.del_sort\n6.search_sort\n7.clrscr\n8.exit");
 printf("\nenter your choice:");
 scanf("%d",&x);
 switch(x)
 {
  case 1:creat(node);      break;
  case 2:display(node);    break;
  case 3:sorting(node);    break;
  case 4:ins_sort(node);   break;
  case 5:del_sort(node);   break;
  case 6:search_sort(node);break;
  case 7:clrscr();         break;
  case 8:exit(0);
  }
 }while(x!=8);
 getch();
 }
 /*--------------------------------*/
 creat()
 {
  int n,i;
  printf("enter the no. of nodes to be creat:");
  scanf("%d",&n);
  node=start;
  for(i=0;i<n;i++)
  {
   node->next=(llist *)malloc(sizeof(llist));
   node=node->next;
   printf("\n the value of node:");
   scanf("%d",&node->info);
   node->next=NULL;
   }
   return;
  }
 /*--------------------------------*/
 display()
 {
  node=start->next;
  while(node)
  {
   printf("%d->",node->info);
   node=node->next;
   }
   return;
  }
 /*-------------------------------*/
  search_sort(llist *node)
  {
   int item,loc=0,flag=0;
   printf("the element to be search is:");
   scanf("%d",&item);
   node=start->next;
   if(node==NULL)
       printf("\n list is empty");
   else
       while(node!=NULL)
       {
	if(item<node->info)
	   {printf("\nsearch is unsuccesfull & element is not found in list");return;}
	else if(node->info==item)
	     {
	      printf("\n search is successfull");
	      printf("\n item founded is at:%d",loc+1);
	      flag=1;return;
	     }
	else if(item>node->info)
		node=node->next;
	 loc++;
	}
    if(flag==0)
    printf("\nsearch is unsuccesfull & element is not found in list");
    return;
  }
  /*------------------------------*/
  ins_sort()
  {
   node=start->next;
   prev=start;
   if(node==NULL)
   {printf("list is empty");return;}
  else
   {
     temp=(llist *)malloc(sizeof(llist));
     printf("enter the item to insert:");
     scanf("%d",&temp->info);
     while(node!=NULL)
     {
       if(temp->info<=node->info)
      {
       temp->next=node;
       prev->next=temp;
       printf("\n after insertion list is:");
       display(node);
       return;
       }
      else
	 {node=node->next;prev=prev->next;}
       }
      if(temp->info>node->info)
      {
       prev->next=temp;
       temp->next=NULL;
       printf("\n after insertion list is:");
       display(node);
      }
   }
     return;
  }
/*--------------------------------*/
 sorting()
{
 int temp;
 prev=start;
 while(prev->next!=NULL)
 {
  node=prev->next;
  while(node!=NULL)
  {
   if(prev->info>node->info)
   {temp=prev->info;prev->info=node->info;node->info=temp;}
   else
    node=node->next;
   }
  prev=prev->next;
 }
 printf("\n sorted list is:");
 display(node);
 return;
 }
 /*------------------------*/
 del_sort(llist *node)
 {
  int value;
  node=start->next;
  prev=start;
  printf("\n the node u want to delet:");
  scanf("%d",&value);
  while(node!=NULL)
  {
   if(value<node->info)
      {printf("\n element absent in list");return;}
   else if(value==node->info)
	  {
	   prev->next=node->next;
	   printf("\n the deleted element is:%d",node->info);
	   free(node);
	   return;
	  }
   else
       {node=node->next;prev=prev->next;}
   }
   if(prev->info<value)
    printf("\n element absent");
   printf("\n after deletion list is:");
   display(node);
   return;
  }
