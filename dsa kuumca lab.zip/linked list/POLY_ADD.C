/*addition of two polynomials*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	 int coeff,expo;
	 struct list *next;
	 };
typedef struct list polylist;
polylist *start,*node,*node1,*node2,*node3,*start1,*start2,*start3;
void main()
{
 node1=node2=node3=NULL;
 clrscr();
 printf("\t\t\t ADDITION OF TWO POLYNOMIALS");
 printf("\n\t\t====================================");
 printf("\n the first list is:\n");
 printf("--------------------------");
 creat(&node1);
 printf("\n after creating list1 is:\n");
 display(node1);
 printf("\n the second list is:\n");
 printf("----------------------------");
 creat(&node2);
 printf("\n after creating list2 is:\n");
 display(node2);
 poly_add(node1,node2,&node3);
 printf("\n after addition of two polynomials result list is:");
 display(node3);
 getch();
 delpoly(&node1);
 delpoly(&node2);
 delpoly(&node3);
 }
 /*----------------------*/
 creat(polylist **node)
 {
  int a,coeff,expo;
  printf("\n enter the terms:");
  while(a!=0)
  {
   printf("\nthe coefficient is:");
   scanf("%d",&coeff);
   printf("\nthe exponent is:");
   scanf("%d",&expo);
   addnode(node,coeff,expo);
   printf("do u want more(exit=0):");
   scanf("%d",&a);
   }
  return;
 }
 /*-------------------------*/
 display(polylist *node)
 {
  if(node!=NULL)
   printf("%dx^%d",node->coeff,node->expo);
  for(node=node->next;node!=NULL;node=node->next)
  {
   if(node->coeff>0)
     printf("+");
   if(node->expo==0)
    printf("%d",node->coeff);
   else
    if(node->expo==1)
     printf("%dx",node->coeff);
   else
     printf("%dx^%d",node->coeff,node->expo);
   }
  return;
  }
  /*-----------------------*/
  poly_add(polylist *node1,polylist *node2,polylist **node3)
  {
   int expo,coeff;
   while((node1!=NULL)&&(node2!=NULL))
   {
    if((node1->expo)>(node2->expo))
    {
     expo=node1->expo;
     coeff=node1->coeff;
     node1=node1->next;
     }
    else if((node1->expo)<(node2->expo))
    {
     expo=node2->expo;
     coeff=node2->coeff;
     node2=node2->next;
     }
    else
    {
     expo=node1->expo;
     coeff=(node1->coeff)+(node2->coeff);
     node1=node1->next;
     node2=node2->next;
     }
    if(coeff!=0)
      addnode(node3,coeff,expo);
   }
   if(node1==NULL)
   {
    for(;node2!=NULL;node2=node2->next)
      addnode(node3,node2->coeff,node2->expo);
    }
   else if(node2==NULL)
	{
	 for(;node1!=NULL;node1=node1->next)
	  addnode(node3,node1->coeff,node1->expo);
	}
   return;
  }
  /*-----------------------------*/
  delpoly(polylist **node)
  {
   polylist *temp;
   while(*node!=NULL)
   {
    temp=*node;
    *node=(*node)->next;
    free(temp);
    }
    return;
    }
   /*---------------------------------*/
  addnode(polylist **node,int coeff,int expo)
  {
    polylist *new;
    new=(polylist *)malloc(sizeof(polylist));
    new->coeff=coeff;
    new->expo=expo;
    if(*node==NULL)
    {
     new->next=NULL;
     *node=new;
     }
    else
     {
      new->next=*node;
      *node=new;
      }
    return;
  }