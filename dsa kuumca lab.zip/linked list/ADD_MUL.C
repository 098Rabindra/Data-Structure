#include<stdio.h>
#include<conio.h>
struct list
	{
	 int a,b,c,d;
	 struct list *next;
	 };
typedef struct list polylist;
polylist *head1,*head2,*head3,*ptr,*new,*last;
int i;
void main()
{
 clrscr();
 head1=head2=head3=NULL;
 do{
 printf("\n**** ADDITION & MULTIPLICATION OF TWO POLYNOMIALS ********\n");
 printf("\n1.creat_poly\n2.creat_poly\n3.add_poly\n4.mul_poly\n5.exit");
 printf("\n enter ur choice:");
 scanf("%d",&i);
 switch(i)
 {
  case 1:creat_poly(head1);break;
  case 2:creat_poly(head2);break;
  case 3:add_poly(head1,head2);display(head3);break;
  case 4:mul_poly();break;
  case 5:exit(0);
  }
 }while(i!=5);
 getch();
 }
 /*-------------------*/
creat_poly()
{
 new=(polylist *)malloc(sizeof(polylist));
 printf("\nenter the coefficient:");
 scanf("%d",&new->d);
 printf("\nenter the power of x:");
 scanf("%d",&new->a);
 printf("\nenter the power of y:");
 scanf("%d",&new->b);
 printf("\nenter the power of z:");
 scanf("%d",&new->c);
 new->next=NULL;
 if(i==1&&head1==NULL) head1=new;
 else
	if(i==2&&head2==NULL) head2=new;
	else
	    {	if(i==1) ptr=head1;
		else ptr=head2;
   while(ptr->next!=NULL)
	ptr=ptr->next;
  ptr->next=new;}
  return;
  }
  /*-------------------*/
  add_poly(polylist *headx,polylist *heady)
  {
   polylist *p,*q;
   ptr=head3=NULL;
   p=headx;q=heady;
   if(p==NULL) {head3=q;return;}
   if(q==NULL) {head3=p;return;}
   while(p!=NULL&&q!=NULL)
   {
    if((p->a==q->a)&&(p->b==q->b)&&(p->c==q->c))
     { if((p->d+q->d)!=0)
       {
	  poly_last(p->a,p->b,p->c,p->d+q->d);
	  p=p->next;
	  q=q->next;
	  }
	}
      else
	   if((p->a>q->a)||((p->a==q->a)&&(p->b>q->b))||((p->a==q->a)&&(p->b==q->b)&&(p->c>q->c)))
	   {
	    poly_last(p->a,p->b,p->c,p->d);
	    p=p->next;
	    }
      else
	   {
	    poly_last(q->a,q->b,q->c,q->d);
	    q=q->next;
	    }
       }
	if(p!=NULL) last->next=p;
	else  last->next=q;
     return;
     }
/*-------------------*/
display(polylist *head)
{
 printf("\nYOUR FIRST POLYNOMIAL IS:");
 ptr=head1;
 while(ptr!=NULL)
 {
  printf("(%dX^%dY^%dZ^%d)+",ptr->d,ptr->a,ptr->b,ptr->c);
  ptr=ptr->next;
  }
 printf("\nYOUR SECOND POLYNOMIAL IS:");
 ptr=head2;
 while(ptr!=NULL)
 {
  printf("(%dX^%dY^%dZ^%d)+",ptr->d,ptr->a,ptr->b,ptr->c);
  ptr=ptr->next;
  }
  printf("\nYOUR RESULTANT POLYNOMIAL IS:");
  ptr=head;
  while(ptr!=NULL)
  {
   printf("(%dX^%dY^%dZ^%d)+",ptr->d,ptr->a,ptr->b,ptr->c);
   ptr=ptr->next;
   }
   return;
   }
 /*------------------------*/
mul_poly()
{          polylist *head,*x,*y,*head4;
	  x=head1;y=head2;
	    head3=head4=head=NULL;
       while(y!=NULL)
    {
	     while(x!=NULL)
	    {   poly_last(y->a+x->a,y->b+x->b,y->c+x->c,y->d*x->d);
		 x=x->next;
	   }  head4=head3;
	      add_poly(head,head4);
	      head=head3;
	      x=head1;
	      y=y->next;
	      head3=NULL;
	}
	     display(head);
	     return;
     }
     /*-------------------*/
     poly_last(int a1,int b1,int c1,int d1)
   {
		     new=(polylist *)malloc(sizeof(polylist));
		     new->a=a1;
		     new->b=b1;
		     new->c=c1;
		     new->d=d1;
		     new->next=NULL;
		   if(head3==NULL)
		   last=head3=new;
		     else
		     { last->next=new;
		     last=new;
		     }   return;
		  }