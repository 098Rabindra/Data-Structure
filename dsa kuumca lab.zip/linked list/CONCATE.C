/*concatenation of two lists*/
#include<stdio.h>
#include<conio.h>
struct list
   {
    int info;
    struct list *next;
    };
typedef struct list conlist;
conlist *start,*first,*sec,*third,*node;
void main()
{
 clrscr();
 first=(conlist *)malloc(sizeof(conlist));
 creat(first);
 display(first);
 sec=(conlist *)malloc(sizeof(conlist));
 creat(sec);
 display(sec);
 third=(conlist *)malloc(sizeof(conlist));
 concate(first,sec,third);
 printf("\n after concatenation list is:\n");
 display(third);
 getch();
}
creat(conlist *node)
{
 int i,n;
 printf("\n no. of elements u want to be creat:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\n value of node:");
  scanf("%d",&node->info);
  node->next=(conlist *)malloc(sizeof(conlist));
  node=node->next;
  node->next='\0';
  }return;
 }
 /*-------------------------*/
 display(conlist *node)
 {
  while(node->next)
  {
   printf("%d->",node->info);
   node=node->next;
   }return;
  }
 /*-------------------------*/
 concate(conlist *first,conlist *sec,conlist *third)
 {
  while(first->next!=NULL)
  {
   third->info=first->info;
   first=first->next;
   third->next=(conlist *)malloc(sizeof(conlist));
   third=third->next;
   }
  while(sec->next!=NULL)
  {
   third->info=sec->info;
   sec=sec->next;
   third->next=(conlist *)malloc(sizeof(conlist));
   third=third->next;
   }
  third->next=NULL;
  return;
  }