/*implementation of stack using linked list*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	 int info;
	 struct list *next;
	 }*start;
typedef struct list stlist;
void display(stlist *);
stlist *push(stlist *);
stlist *pop(stlist *);
void main()
{
 int x;
 stlist *start;
 start=NULL;
 clrscr();
 printf("\n\tIMPLEMENTATION OF STACK USING LINKED LIST");
 printf("\n\t=======================================================");
 do
 {
  printf("\n1.push\n2.pop\n3.exit");
  printf("\n enter ur choice:");
  scanf("%d",&x);
  switch(x)
  {
   case 1:
	 start=push(start);
	 printf("\nafter push stack is:");
	 display(start);
	 break;
   case 2:
	  start=pop(start);break;
   case 3:exit(0);
   }
   }while(x!=3);
  getch();
 }
 /*----------------------*/
 void display(stlist *node)
 {
  while(node!=NULL)
  {
   printf("%d->",node->info);
   node=node->next;
   }
  }
  /*----------------------*/
 stlist *push(stlist *node)
 {
   stlist *new;
   printf("\n the new value of the stack is:");
   new=(stlist *)malloc(sizeof(stlist));
   scanf("%d",&new->info);
   new->next=node;
   node=new;
   return(node);
   }
  /*---------------------*/
 stlist *pop(stlist *node)
  {
   stlist *temp;
   if(node==NULL)
     printf("\n stack is empty");
   else
   {
    temp=node->next;
    free(node);
    node=temp;
    printf("\n after pop the stack is:");
    display(node);
    if(node==NULL)
    printf("\n stack is empty");
    }
   return(node);
   }
  /*--------------------*/
