/*circular linked list*/
#include<stdio.h>
#include<conio.h>
struct list
   {
    int info;
    struct list *next;
    };
typedef struct list clist;
clist *start,*node,*count,*new1,prev;
int no;
void main()
{
 int x;
 clist *node;
 clrscr();
 node=(clist *)malloc(sizeof(clist));
 do{
 printf("\nCIRCULAR LINKED LIST");
 printf("\n------------------------------");
 printf("\n1.creat\n2.display\n3.insert\n4.delet\n5.search\n6.clrscr\n7.exit");
 printf("\n enter ur choice:");
 scanf("%d",&x);
 switch(x)
 {
  case 1:creat(node);break;
  case 2:display(node);break;
  case 3:insert(node);break;
  case 4:delet(node);break;
  case 5:search(node);break;
  case 6:clrscr();break;
  case 7:exit();
  }
 }while(x!=7);
 getch();
 }
 /*-------------------------*/
 creat(clist *node)
 {
  int i,n,value;
  node=(clist *)malloc(sizeof(clist));
  node=start;
  printf("\n enter no. of nodes to be creat:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
  node->next=(clist *)malloc(sizeof(clist));
  node=node->next;
  printf("\nvalue=");
  scanf("%d",&node->info);
  }
  node->next=start;
  return;
  }
  /*----------------------*/
  display(clist *node)
  {
   node=start->next;
   while(node!=start)
   {
    printf("%d->",node->info);
    node=node->next;
    }
   return;
  }
  /*--------------------------*/
  insert(clist *node)
  {
   int no=0,ins_node;
   clist *prev;
   node=start->next;
   prev=start;
   new1=(clist *)malloc(sizeof(clist));
   printf("the value of node:");
   scanf("%d",&new1->info);
   printf("input node no. u want to insert:");
   scanf("%d",&ins_node);
   while(node!=start)
   {
    if((no+1)==ins_node)
    {new1->next=node;prev->next=new1;}
    else  if(node==NULL)
	  {prev->next=new1;new1->next=NULL;}
    else
	  {node=node->next;prev=prev->next;}
    no++;
   }
    printf("\n after insertion list is:");
    display(node);
  return;
  }
  /*--------------------------------*/
  delet(clist *node)
  {
   int no=0,del_node;
   clist *prev;
   node=start->next;
   prev=start;
   printf("input node no. u want to delet:");
   scanf("%d",&del_node);
   while(node!=start)
   {
    if((no+1)==del_node)
    {
     prev->next=node->next;
     printf("the value of node deleted:%d",node->info);
     free(node);
     }
    else
       {node=node->next;prev=prev->next;}
    no++;
   }
    printf("\n after deletion list is:");
    display(node);
  return;
  }
  /*--------------------------------*/
 search(clist *node)
 {
   int no=0,item,flag=0;
   node=start->next;
   printf("\n node value u want to search:");
   scanf("%d",&item);
   while(node!=start)
   {
    if(item==node->info)
    {
     printf("\n search is succesful");
     printf("\n element found at:%d",no+1);
     flag=1; return;
     }
    else
     node=node->next;
    no++;
    }
    if(flag==0)
    printf("\n search is unsuccesful &element is not found");
   return;
  }
