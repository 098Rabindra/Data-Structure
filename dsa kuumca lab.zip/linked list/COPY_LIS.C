/*copy of linked list*/
#include<stdio.h>
#include<conio.h>
struct list
   {
    int info;
    struct list *next;
    };
typedef struct list coplist;
coplist *start,*node1,*start1,*node;
void main()
{
 clrscr();
 printf("\n\t\t COPY OF LINKED LIST");
 printf("\n\t\t---------------------------");
 node=(coplist *)malloc(sizeof(coplist));
 creat(node);
 display(node);
 node1=(coplist *)malloc(sizeof(coplist));
 copy(node,node1);
 printf("\n after copy list is:\n");
 display(node1);
 getch();
}
creat(coplist *node)
{
 int i,n;
 printf("\n no. of elements u want to be insert:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\n value of node:");
  scanf("%d",&node->info);
  node->next=(coplist *)malloc(sizeof(coplist));
  node=node->next;
  node->next='\0';
  }return;
 }
 /*-------------------------*/
 display(coplist *node)
 {
  while(node->next!=NULL)
  {
   printf("%d->",node->info);
   node=node->next;
   }return;
  }
 /*-------------------------*/
 copy(coplist *node,coplist *node1)
 {
   while(node->next!=NULL)
   {
    node1->info=node->info;
    node1->next=(coplist *)malloc(sizeof(coplist));
    node1=node1->next;
    node=node->next;
    node1->next=NULL;
   }
  return;
  }

