/*IMPLEMENT A LINKED LIST*/
#include<stdio.h>
#include<conio.h>
struct list
       {
	int info;
	struct list *next;
	};
typedef struct list llist;
llist *start,*temp,*prev,*loc,*value;
void main()
{
 int x;
 llist *node;
 clrscr();
 node=(llist *)malloc(sizeof(llist));
do
{
 printf("\n1.creat\n2.display\n3.ins_beg\n4.ins_end\n5.ins_loc\n6.ins_info");
 printf("\n7.del_beg\n8.del_end\n9.del_loc\n10.del_info\n11.del_sec\n12.count\n13.clrscr\n14.exit");
 printf("\nenter your choice:");
 scanf("%d",&x);
switch(x)
 {
  case 1: creat(node);   break;
  case 2: display(node); break;
  case 3: ins_beg(node); break;
  case 4: ins_end(node); break;
  case 5: ins_loc(node); break;
  case 6: ins_info(node);break;
  case 7: del_beg(node); break;
  case 8: del_end(node); break;
  case 9: del_loc(node); break;
  case 10:del_info(node);break;
  case 11:del_sec(node); break;
  case 12:count(node);   break;
  case 13:clrscr();      break;
  case 14:exit(0);
 }
 }while(x!=14);
 getch();
}
 /*--------------------------------*/
 creat(llist *node)
 {
  int n,i;
  node=start;
  start->next=NULL;
  printf("enter the no. of nodes to be creat:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
   node->next=(llist *)malloc(sizeof(llist));
   node=node->next;
   printf("\n the value of node:");
   scanf("%d",&node->info);
   node->next=NULL;
   }return;
  }
 /*--------------------------------*/
 display(llist *node)
 {
  node=start->next;
  while(node!=NULL)
  {
   printf("%d->",node->info);
   node=node->next;
   }
   return;
  }
 /*-------------------------------*/
 ins_beg(llist *node)
 {
  node=start->next;
  prev=start;
  temp=(llist *)malloc(sizeof(llist));
  printf("\n enter the data:");
  scanf("%d",&temp->info);
  temp->next=node;
  prev->next=temp;
  display(node);
  return;
  }
 /*-----------------------------*/
 ins_end(llist *node)
 {
  node=start;
  temp=(llist *)malloc(sizeof(llist));
  while(node->next!=NULL)
    node=node->next;
  printf("\n enter the data:");
  scanf("%d",&temp->info);
  node->next=temp;
  temp->next=NULL;
  display(node);
  return;
  }
 /*-----------------------------*/
 ins_loc(llist *node)
 {
  int loc,a=1;
  node=start->next;
  prev=start;
  temp=(llist *)malloc(sizeof(llist));
  printf("\nenter the location of insertion:");
  scanf("%d",&loc);
  printf("\n enter the data:");
  scanf("%d",&temp->info);
  while(loc!=a)
  {
    node=node->next;
    prev=prev->next;
    a++;
   }
  prev->next=temp;
  temp->next=node;
  display(node);
  return;
  }
 /*-----------------------------*/
 ins_info(llist *node)
 {
  int value;
  node=start->next;
  temp=(llist *)malloc(sizeof(llist));
  printf("\nenter the information after which,want to insert:");
  scanf("%d",&value);
  printf("\n enter the data:");
  scanf("%d",&temp->info);
  while(node->info!=value)
    node=node->next;
   temp->next=node->next;
   node->next=temp;
  display(node);
  return;
  }
  /*--------------------------------*/
  del_beg(llist *node)
  {
   node=start->next;
   start->next=node->next;
   printf("\n the element deleted is:%d\n",node->info);
   free(node);
   display(node);
   return;
   }
   /*---------------------------------*/
   del_end(llist *node)
   {
    node=start->next;
    prev=start;
    while(node->next!=NULL)
    {
     node=node->next;
     prev=prev->next;
     }
    prev->next=node->next;
    printf("\n the element deleted is:%d\n",node->info);
    free(node);
    display(node);
    return;
   }
   /*----------------------------------*/
   del_loc(llist *node)
   {
    int c=1,loc;
    node=start->next;
    prev=start;
    printf("\nenter the location of deletion:");
    scanf("%d",&loc);
    while(loc!=c)
    {
      node=node->next;
      prev=prev->next;
      c++;
    }
    prev->next=node->next;
    printf("\n the element deleted is:%d\n",node->info);
    free(node);
    display(node);
    return;
   }
   /*----------------------------------*/
 del_info(llist *node)
 {
  int value;
  node=start->next;
  prev=start;
  printf("\nenter the information after which,want to delet:");
  scanf("%d",&value);
  while(node->info!=value)
  {
    node=node->next;
    prev=prev->next;
   }
   prev->next=node->next;
   printf("\n the element deleted is:%d\n",node->info);
   free(node);
   display(node);
  return;
  }
  /*--------------------------------*/
  count(llist *node)
  {
   int num=0;
   node=start;
   while(node->next!=NULL)
   {
     node=node->next;
     num++;
    }
   printf("no. of nodes in the list is:%d",num);
   return;
   }
   /*----------------------------*/
   del_sec(llist *node)
   {
    int c=1;
    node=start->next;
    prev=start;
    while(node!=NULL)
    {
     if(c%2==0)
     {
      prev->next=node->next;
      printf("\n the delet node=%d",node->info);
      free(node);
      }
      else
      {
       node=node->next;
       prev=prev->next;
       }
     c++;
     }
   display(node);
   return;
  }
