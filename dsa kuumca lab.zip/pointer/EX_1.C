#include<stdio.h>
main()
{
int j;
int *a;
int k[20];
clrscr();
//a=(int *)malloc(5*sizeof(int));
//printf("%u",a);
a=k;
for(j=0;j<5;j++)
{
 printf("no.=%d\t",j+1);
 scanf("%d",(a+j));
 }
 for(j=0;j<5;j++)
 printf("%d\n",*(a+j));
 getch();
 }