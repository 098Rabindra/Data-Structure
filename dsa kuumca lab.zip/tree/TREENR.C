/*tree traversal*/
#include<stdio.h>
#include<conio.h>
char t[50],ptr;int i,top,s[50];
void main()
{
 int x;
 clrscr();
 printf("\n the tree is:");
 gets(t);
 for(i=0;t[i]!='\0';i++);
 if(i==0) printf("\n tree is empty");
 printf("\n");
 do{
 printf("\n1.preorder\n2.inorder\n3.postorder\n4.exit");
 printf("\n enter ur choice:");
 scanf("%d",&x);
 switch(x)
 {
  case 1:preorder();break;
  case 2:inorder();break;
  case 3:postorder();break;
  case 4:exit(0);
  }
  }while(x!=4);
 getch();
 }
 /*------------------------*/
 preorder()
 {
	printf("\n*****PREORDER****\n");
	top=1;
	s[top]=NULL;ptr=1;
	  while(t[ptr]!='*')
	  {
	   printf("%c",t[ptr]);
	  if(t[2*ptr+1]!='*')
	  {
	   top++;
	   s[top]=2*ptr+1;
	   }
	  if(t[2*ptr]!='*')
	  {
	   ptr=2*ptr;
	   }
	  else
	  {
	   ptr=s[top];
	   top--;
	   }
      }
      return;
      }
 inorder()
 {
	     printf("\n****INORDER***\n");
	     ptr=1;top=1;s[top]=NULL;
	     while(t[ptr]!='*')
	     {
	      top++;s[top]=ptr;
	      ptr=2*ptr;
	      }
	     ptr=s[top];top--;
	     while(t[top]!='*')
	     {
	      printf("%c",t[ptr]);
	      if(t[2*ptr+1]!='*')
	      {
	       ptr=2*ptr+1;
		 while(t[ptr]!='*')
		 {
		   top++;s[top]=ptr;
		    ptr=2*ptr;
		  }
	       }
	      ptr=s[top];top--;
	     }
	     return;
	  }
postorder()
{
	      printf("\n****POSTORDER*****\n");
	      ptr=1;top=1;s[top]=NULL;
	  lab:while(t[ptr]!='*')
	      {
	       top++;s[top]=ptr;
	       if(t[ptr*2+1]!='*')
	       {
		top++;s[top]=-(2*ptr+1);
		}
	       ptr=2*ptr;
	       }
	      ptr=s[top];top--;
	      while(ptr>0)
	      {
	       printf("%c",t[ptr]);
	       ptr=s[top];top--;
	       }
	     if(ptr<0)
	     {
	      ptr=-ptr;
	      goto lab;
	      }
	    return;
	    }
