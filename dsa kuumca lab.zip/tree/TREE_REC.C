/*tree traversal*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	char info;
	struct list *left;
	struct list *right;
	};
typedef struct list tree;tree *t;
tree *creat_tree(char *,int,int);
void display(tree *,int);
void pre_order(tree *);
void in_order(tree *);
void post_order(tree *);
/*function main*/
void main()
{
 int x,n=0;
 char l[100],info;
 clrscr();
 t=(tree *)malloc(sizeof(tree));
 t=NULL;
 printf("x=");
 scanf("%d",&x);
 while(x !=0)
 {
  printf("the value of node:");
  scanf("%s",&info);
  l[n++]=info;
  fflush(stdin);
  printf("\n do you want more(exit=0):");
  scanf("%d",&x);
  fflush(stdin);
  }
  n--;
  printf("\n no. of elements in the list:%d",n);
  t=creat_tree(l,0,n);
  clrscr();
  printf("\ntree is:");
  display(t,1);
  printf("\n pre_order\n");
  pre_order(t);
  printf("\nin_order\n");
  in_order(t);
  printf("\npost_order\n");
  post_order(t);
  getch();
 }
 /*-------------------------*/
 tree *creat_tree(char *l,int lo,int up)
 {
  tree *node;
  int mid=(lo+up)/2;
  node=(tree *)malloc(sizeof(tree));
  node->info=l[mid];
  if(lo>=up)
  {
   node->left=NULL;
   node->right=NULL;
   return(node);
   }
  if(lo<=mid-1)
    node->left=creat_tree(l,lo,mid-1);
  else
    node->left=NULL;
  if(mid+1<=up)
   node->right=creat_tree(l,mid+1,up);
  else
   node->right=NULL;
  return(node);
  }
  /*--------------------------*/
void display(tree *t,int level)
  {
   int i;
   if(t)
   {
    display(t->right,level+1);
    printf("\n");
    for(i=0;i<level;i++)
    printf(" ");
    printf("%c",t->info);
    printf("\n");
    display(t->left,level+1);
    }
   }
   /*---------------------------*/
void pre_order(tree *node)
 {
  if(node)
  {
   printf("%c",node->info);
   pre_order(node->left);
   pre_order(node->right);
   }
  }
  /*-----------------------*/
 void in_order(tree *node)
  {
   if(node)
   {
    in_order(node->left);
    printf("%c",node->info);
    in_order(node->right);
    }
  }
  /*---------------------------*/
void post_order(tree *node)
  {
   if(node)
   {
   post_order(node->left);
   post_order(node->right);
   printf("%c",node->info);
   }
 }
 /*---------------------------*/




