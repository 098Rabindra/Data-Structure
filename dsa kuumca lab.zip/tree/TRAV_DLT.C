/*tree traversal*/
#include<stdio.h>
#include<conio.h>
struct list
	{
	char info;
	struct list *left;
	struct list *right;
	};
typedef struct list tree;
tree *top,*node,*root,*ptr,*s;
void main()
{
 int x;
 clrscr();
 printf("\n1.preorder\n2.inorder\n3.postorder\n4.exit");
 printf("\n enter ur choice:");
 scanf("%d",&x);
 switch(x)
 {
  case 1:preorder();break;
  case 2:inorder();break;
  case 3:postorder();break;
  case 4:exit(0);
  }
  getch();
 }
 /*------------------*/
 preorder()
 {
  int s[30];
  tree *node;
  top=1;s[1]=NULL;
  node=(start->next)->info;
  while(node!=NULL)
  {
   printf("%c",node->info);
   if(node->right!=NULL)
   {
    top++;
    s[top]=(node->right)->info;
    }
   if(node->left!=NULL)
   {
    node=node->left;
    }
   else
   {
    node=s[top];
    top--;
    }
  }
  return;
  }



