/*tree traversal*/
#include<stdio.h>
#include<conio.h>
int i;char t[50];
void main()
{
 int x;
 void preorder();
 void inorder();
 void postorder();
 clrscr();
 printf("\n the tree is:");
 gets(t);
 for(i=0;t[i]!='\0';i++);
 do{
 printf("\n1.preorder\n2.inorder\n3.postorder\n4.exit");
 printf("\n enter ur choice:");
 scanf("%d",&x);
 switch(x)
 {
  case 1:
	printf("\n**PREORDER**\n");
	preorder(1);
	break;
  case 2:printf("\n**INORDER**\n");
	 inorder(1);
	 break;
  case 3:
	 printf("\n**POSTORDER**\n");
	 postorder(1);
	 break;
  case 4:exit(0);
  }
 }while(x!=4);
 getch();
 }
 /*---------------*/
void preorder(int j)
{
 printf("%c",t[j-1]);
 if(2*j<=i)
 preorder(2*j);
 if(2*j+1<=i)
 preorder(2*j+1);
}

/*-------------------*/
void inorder(int j)
{
 if(2*j<=i)
 inorder(2*j);
 printf("%c",t[j-1]);
 if(2*j+1<=i)
 inorder(2*j+1);
 }
 /*-----------------*/
void postorder(int j)
 {
  if(2*j<=i)
  postorder(2*j);
  if(2*j+1<=i)
  postorder(2*j+1);
  printf("%c",t[j-1]);
  }
