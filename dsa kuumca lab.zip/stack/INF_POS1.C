/*convertion of infix to postfix expression*/
#include<stdio.h>
#include<conio.h>
int  precedence (char s,char q)
{
 if(s=='^') return(1);
 else if((s=='/'||s=='*')&&(q!='^')) return(1);
 else if((s=='+'||s=='-')&&(q!='/'&&q!='*')) return(1);
 else return(0);
 }
void main()
{
  char p[50],q[50],s[50],ch;
  int top,i,j,k,l;
  do
   {
    top=0,i=0,j=-1;
    clrscr();
    printf("enter the infix expression:");
    gets(q);
    l=strlen(q);
    q[l]=')';q[++l]='\0';s[top]='(';
    while(top>=0)
    {
     if(q[i]=='(')
     {top++;s[top]=q[i];i++;}
     else
       if((q[i]>='A'&&q[i]<='Z')||(q[i]>='a'&&q[i]<='z'))
       {j++;p[j]=q[i];i++;}
       else if(q[i]==')')
	    {
	      while(s[top]!='(')
	      { j++;p[j]=s[top];top--;}
	      top--;i++;
	     }
	     else
	      {if(s[top]==')')
		   {top++;s[top]=q[i];i++;}
		else
		{
		  k=precedence(s[top],q[i]);
		  while(k)
		  {
		   j++;p[j]=s[top];top--;
		   k=precedence(s[top],q[i]);
		   }
		  top++;s[top]=q[i];i++;
		  }
		 }
		}
	     p[++j]='\0';
	     printf("\n postfix expression is:%s",p);
	     printf("\n do u want to continue:");
	     ch=getch();
	    }
	 while(ch=='y'||ch=='Y');
    }
