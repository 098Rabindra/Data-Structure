/*stack implementation*/
#include<stdio.h>
#include<process.h>
int top,loc,i,n,s[30];char a;
int push();
int pop();
int peep();
int display();
int main()
{
 int c;
 //clrscr();
 printf("enter the size of stack:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 s[i]= '*';
 printf("\n\t\t\tIMPLEMENTATION OF STACK");
 printf("\n\t\t=====================================");
 do
 {
  printf("\n 1.push\n 2.pop\n 3.peep\n 4.exit");
  printf("\n enter your choice:");
  //c=getchar();
  scanf("%d",&c);
  fflush(stdin);
  switch(c)
  {
   case 1:push();break;
   case 2:pop();break;
   case 3:peep();break;
   //case '4':change();break;
   //case '5':clrscr();break;
   case 4:exit(0);
   }
 }while(c!=5);
 return 0;
}
/*---------------------------------*/
push()
{
 if(top==n)
 printf("\n stack overflow");
 else
 {
  printf("\n enter the elements to be push:");
  a=getchar();
  
  top++;
  s[top]=a;
  printf("\n after push the content of stack is:");
  display();
  }return 0;
 }
 /*-----------------------------------*/
 pop()
 {
  if(top<0)
  printf("\n stack underflow");
  else
  {
   a=s[top];
   s[top]='*';
   top--;
   printf("\n the poped element is:%c",a);
   printf("\n after pop the elements of stack is:");
   display();
   }
   return 0;
 }
 /*---------------------------------*/
peep()
{
 printf("\n enter the location to be peeped:");
 scanf("%d",&loc);
 if(top-loc+1<0)
 printf("\n stack underflow");
 else
 {
  a=s[top-loc+1];
  printf("\n element peeped is:%c",a);
  }
  return 0;
 }
 /*-------------------------------*/
 /*change()
 {
  printf("\n enter the location to be changed:");
  scanf("%d",&loc);
  if(top-loc+1<0)
  printf("\n stack underflow");
  else
  {
   printf("\n enter the new element:");
   a=getche();
   s[top-loc+1]=a;
   puts("\n after change the content of stack is:");
   display();
  }
  return;
 }*/
 /*-------------------------*/
 display()
 {
  for(i=1;i<=n;i++)
  printf("%c|",s[i]);
  printf("\n position of top in the stack is :%d",top);
  return 0;
  }

