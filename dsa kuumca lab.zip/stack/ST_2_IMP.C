/*implement two stack using an array*/
#include<stdio.h>
#include<conio.h>
int  a,i,n;
char s[7],top1=0,top2=8,x;
void main()
{
 clrscr();
 printf("enter the size of stack:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 s[i]='*';
 do
 {
  printf("\n 1.push1,\n 2.pop1,\n 3.push2,\n 4.pop2,\n 5.exit.");
  printf("\n enter your choice:");
  scanf("%d",&a);
  switch(a)
  {
    case 1:push1();break;
    case 2:pop1();break;
    case 3:push2();break;
    case 4:pop2();break;
    case 5:exit(0);
    }
 }while(1);
}
 push1()
 {
   if(top1==top2-1)
   printf("\n stack overflow");
   else
   {
    top1=top1+1;
    printf("\n enter the element to be push:");
    x=getche();
    s[top1]=x;
    printf("\n after push the content of stack is :\n");
    display();
   }
   return;
 }
 pop1()
 {
  if (top1==0)
  printf("\n stack underflow");
  else
  {
   x=s[top1];
   s[top1]='*';
   top1--;
   printf("\n the popped element is:%c",x);
   printf("\n after pop stack is :\n");
   display();
   }
   return;
  }
  push2()
  {
   if(top2==top1+1)
   printf("\n stack overflow");
   else
   {
    top2--;
    printf("\n enter the element to be push :");
    x=getche();
    s[top2]=x;
    printf("\n after push the content of stack is :\n");
    display();
   }
   return;
 }
  pop2()
  {
   if(top2>n)
   printf("\n stack underflow");
   else
   {
    x=s[top2];
    s[top2]='*';
    top2++;
    printf("\n the popped element is:%c",x);
    printf("\n after pop stack is :\n");
    display();
    }
    return;
  }
  display()
  {
   int i;
   for(i=1;i<=n;i++)
   printf("%c|",s[i]);
   return;
   }