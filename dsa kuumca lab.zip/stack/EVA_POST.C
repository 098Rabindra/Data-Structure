/*evaluation of post_fix expression*/
#include<stdio.h>
#include<conio.h>
void main()
{
 int i,top;
 char p[50],ch;
 float s[20],value,a,b,c;
 do
 {
  clrscr();
  top=-1;
  printf("enter the expression:");
  gets(p);
  for(i=0;p[i]!='\0';i++)
  {
   if((p[i]>='0') && (p[i]<='9'))
   {
    top++;
    s[top]=p[i]-48;
    }
    else
    {
     a=s[top];
     top--;
     b=s[top];
     switch(p[i])
     {
      case '^':c=pow(a,b);break;
      case '/':c=b/a;     break;
      case '*':c=b*a;     break;
      case '+':c=b+a;     break;
      case '-':c=b-a;     break;
      }
      s[top]=c;
     }
   }
     value=s[top];
     printf("\n value of expresstion:%5.2f",value);
     printf("\n do u wan 2 continue:");
     ch=getche();
  }while(ch=='y'||ch=='Y');
  getch();
 }