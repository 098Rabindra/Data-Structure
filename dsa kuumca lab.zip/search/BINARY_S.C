/*binary search*/
#include<stdio.h>
//#include<conio.h>
int main()
{
  int i,low,high,mid,item,a[30],n,flag=0;
 // clrscr();
  printf("Binary Search");
  printf("\n******************");
  printf("\n enter the no. of elements,want to be insert:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
   scanf("%d",&a[i]);
   for(i=0;i<n;i++)
   printf("%d\t",a[i]);
   
  printf("\n enter the element,to be search:");
  scanf("%d",&item);
  
  low=0;
  high=n-1;
  mid=(low+high)/2;
  while(low<=high&&item!=a[mid])
  {
    if(item<a[mid])
   high=mid-1;
   else if(item>a[mid])
   low=mid+1;
   mid=(low+high)/2;
  }
   if(item==a[mid])
   {
    printf("\n searching is successful");
    printf("\n %d is found at position=%d",item,mid+1);
    flag=1;
   }
   else if(flag==0)
     printf("\n searching is unsuccesful & item can not found");
 //getch();
 return 0;
}
