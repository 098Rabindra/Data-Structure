/*linear search*/
#include<stdio.h>
int main()
{
 int item,i,a[30],n,flag=0;
 
 
 printf("Linear Search");
 printf("\n~~~~~~~~~~~~~~~~~~");
 printf("\n enter the no. of elements,want to be insert:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
  scanf("%d",&a[i]);
  for(i=0;i<n;i++)
   printf("%d\t",a[i]);
   
 printf("\n enter the item to be search:");
 scanf("%d",&item);
 
 for(i=0;i<n;i++)
 {
  if(item==a[i])
  {
   printf("\n searching is succesful");
   printf("\n %d is found at position=%d",item,i+1);
   flag=1;
   }
  }
   if(flag==0)
   printf("\n searching is unsuccesful & item can not be found");
  
  return 0;
}


