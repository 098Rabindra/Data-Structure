/*IMPLEMENT A CIRCULAR_QUEUE*/
#include<stdio.h>
#include<conio.h>
char cq[50],a;
int i,f=0,r=0;
void main()
{
 char c;
 clrscr();
 for(i=1;i<=8;i++)
  cq[i]='*';
 do
  {
   printf("\n 1.insert(),\n 2.delete(),\n 3.exit");
   printf("\n enter your choice:");
   c=getche();
   switch(c)
   {
    case '1':insert();break;
    case '2':delete();break;
    case '3':exit(0);
    }
   }while(1);
 }
 insert()
 {
  if((r==8)&&(f==1))
    { printf("\n circular queue overflow"); return;}
  else
    { if(r==8) r=1;
      else r++;
      printf("\n enter the element,to be insert:");
      a=getche();
      cq[r]=a;
      if(f==0) f=1;
      printf("\n after insertion the contents of circular queue is:\n");
      display();}
      printf("\n the value of front=%d,rear=%d",f,r);
      return;
 }
 delete()
 {
  if(f==0)
    {printf("\n circular queue underflow");return;}
 else
  {
    a=cq[f];cq[f]='*';
    printf("\n element deleted is:%c",a);
    if(f==r) f=r=0;
    else if(f==8) f=1;
    else   f++;
    printf("\n after deletion the contents of circular queue is:\n");
    display();
    printf("\n the value of front=%d,rear=%d",f,r);}
    return;
   }
 display()
 {
  int i;
  if(f==0)
    return;
  else
  {
   for(i=1;i<=8;i++)
   printf("%c|",cq[i]);
   }
   return;
 }