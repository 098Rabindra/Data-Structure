/*implement a deque*/
#include<stdio.h>
#include<conio.h>
char dq[50],a,c;
int i,f=0,r=0;
void main()
{
 char x;
 clrscr();
 printf("\t\t\tIMPLEMENTATION OF A DEQUE");
 printf("\n\t\t======================================");
 for(i=1;i<=8;i++)
 dq[i]='*';
 do
  {
   printf("\n 1.input_restricted_deque\n 2.output_restricted_deque\n 3.exit");
   printf("\n enter your choice:");
   c=getche();
   switch(c)
   {
    case '1':input_restricted_deque();break;
    case '2':output_restricted_deque();break;
    case '3':exit(0);
    }
    printf("\n Do U want to continue(exit=0):");
    x=getche();
   }while(x!=0);
   getch();
 }
 /*------------------------------*/
 input_restricted_deque()
 {
  clrscr();
  printf("\n INPUT RESTICTED DEQUE");
  printf("\n------------------------------");
  do
  {
   printf("\n1.insertr\n2.deletf\n3.deletr\n4.exit");
   printf("\n enter your choice:");
   c=getche();
   switch(c)
   {
    case '1':insertr();break;
    case '2':deletf();break;
    case '3':deletr();break;
    case '4':exit(0);
    }
   }while(1);return;
 }
 /*-------------------------------*/
 output_restricted_deque()
 {
   clrscr();
   printf("\n OUTPUT RESTICTED DEQUE");
   printf("\n------------------------------");
   do
   {
    printf("\n1.insertr\n2.deletf\n3.insertf\n4.exit");
    printf("\n enter your choice:");
    c=getche();
    switch(c)
    {
     case '1':insertr();break;
     case '2':deletf();break;
     case '3':insertf();break;
     case '4':exit(0);
    }
   }while(1); return;
  }
  /*---------------------------------*/
 insertf()
 {
  if((f==1)&&(f==8)||(f==r+1))
  {
   printf("\n Deque Overflow");
   return;}
  else
  {
   if(f==0)
      f=1;
   else if(f==1)
	f=8;
   else f--;
   printf("\n enter the element to be insert:");
   a=getche();
   dq[f]=a;
   if(r==0)
      r=1;
   printf("\n after insertion deque is:\n");
   display();
   printf("\nrear=%d,front=%d",r,f);
  }
  return;
 }
 /*-----------------------------------*/
  insertr()
 {
  if(r==8)
    r=1;
  else r++;
  if(f==r)
  {
   printf("\n Deque Overflow");
   return;}
  else
  {
   printf("\n enter the element to be insert:");
   a=getche();
   dq[r]=a;}
   if(f==0)
      f=1;
   printf("\n after insertion deque is:\n");
   display();
   printf("\nrear=%d,front=%d",r,f);
  return;
 }
 /*----------------------------------------*/
 deletf()
 {
  if(f==0)
  {
   printf("\nDeque Underflow");
   return;}
  else
  {
   a=dq[f];dq[f]='*';
   if(f==r)
      f=r=0;
   else if(f==8)
	   f=1;
   else f++;
   printf("\n after deletion deque is:\n");
   display();
   printf("\nrear=%d,front=%d",r,f);
  }
  return;
 }
 /*---------------------------------*/
 deletr()
 {
  if(r==0)
  {
   printf("\n Deque Underflow");
   return;}
  else
  {
   a=dq[r];dq[r]='*';
   if(f==r)
      f=r=0;
   else if(r==1)
	   r=8;
   else r--;
   printf("\n after deletion deque is:\n");
   display();
   printf("\nrear=%d,front=%d",r,f);
  }
  return;
 }
 /*---------------------------*/
 display()
 {
  if((f==0)&&(r==0))
  return;
  else
  {
   for(i=1;i<=8;i++)
   printf("%c|",dq[i]);
   return;
   }
 }

