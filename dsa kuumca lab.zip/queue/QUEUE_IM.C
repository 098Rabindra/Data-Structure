/*IMPLEMENT A QUEUE*/
#include<stdio.h>
#include<process.h>
char q[50],a;
int f=0,r=0,i;
int insert();
int delet();
int display();
int main()
{
 int c;
 //clrscr();
 for(i=1;i<=8;i++)
 q[i]='*';
 do
  {
   printf("\n 1.insert(),\n 2.delete(),\n 3.exit");
   printf("\n enter your choice:");
   scanf("%d",&c);
   fflush(stdin);
   switch(c)
   {
    case 1:insert();break;
    case 2:delet();break;
    case 3:exit(0);
    }
   }while(c!=4);
   return 0;
 }
 insert()
 {
  if(r==8)
  printf("\n queue overflow");
  else
  {
   printf("\n enter the element,to be insert:");
   a=getchar();
   r++; q[r]=a;
   if(f==0)  f=1;
   printf("\n after insertion the contents of queue is:\n");
   display();
   printf("\n the values of front=%d,rear=%d",f,r);
   }return 0;
 }
delet()
 {
  if(f==0)
  printf("\n queue underflow");
  else
  {
   a=q[f];q[f]='*';
   printf("\n element deleted is:%c",a);
   }
   if(f==r) f=r=0;
   else
   f++;
   printf("\n after deletion the contents of queue is:\n");
   display();
   printf("\n the values of front=%d,rear=%d",f,r);
   return(a);
 }
 display()
 {
  if(f==0)return 0;
  for(i=1;i<=8;i++)
  printf("%c|",q[i]);
  return 0;
  }
